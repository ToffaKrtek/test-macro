<?php
//DATABASE keys
return array(
  'host' => 'localhost',
  'dbname' => 'test',
  'user' => 'test',
  'password' => 'password',
);
?>
